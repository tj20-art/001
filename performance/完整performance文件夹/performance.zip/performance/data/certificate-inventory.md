# JMeter account certificate inventory

Certificate presence, CN and validity were checked locally. Database roles, revocation and passwords were not authenticated. Times below use Asia/Shanghai.

| Username | Certificate filename | Valid until |
|---|---|---|
| user0010 | user0010_certificate.crt | 2027-07-01 00:07:07 |
| user0011 | user0011_certificate.crt | 2027-07-01 00:17:52 |
| user0012 | user0012_certificate.crt | 2027-07-01 01:08:40 |
| user0013 | user0013_certificate.crt | 2027-07-01 01:13:50 |
| user015 | user015_certificate.crt | 2027-11-04 22:43:46 |
| user016 | user016_certificate.crt | 2027-11-04 22:44:39 |
| user017 | user017_certificate.crt | 2027-11-04 22:45:18 |
| user018 | user018_certificate.crt | 2027-11-04 22:45:51 |
| user019 | user019_certificate.crt | 2027-11-04 22:46:29 |

CSV schema (no header): cert_path,password,product_id

users-local-5.csv contains the first five accounts; users-local.csv contains all nine. Product ID defaults to 3. Local CSV files are excluded by .gitignore.
