# JMeter本地账号数据

users-local-5.csv：前5个账号，供5线程测试使用。

users-local.csv：全部9个账号，最多供9个独立线程使用。10线程还缺1个账号，20线程还缺11个账号。

两份CSV均为UTF-8、不带BOM、无表头。三列依次为证书完整路径、密码、商品ID。密码末尾已按用户确认使用英文半角感叹号。商品ID默认3，修改测试商品时编辑第三列。原证书文件未复制或重命名。

## JMeter配置

在线程组下添加 Config Element → CSV Data Set Config：

| 字段 | 值 |
|---|---|
| Filename | C:/Users/r7000/PycharmProjects/PythonProject1/performance/data/users-local-5.csv |
| File encoding | UTF-8 |
| Variable Names | cert_path,password,product_id |
| Delimiter | , |
| Ignore first line | False（文件无表头） |
| Allow quoted data | True |
| Recycle on EOF | False |
| Stop thread on EOF | True |
| Sharing mode | All threads |

登录请求：Parameters中的password值改为 `${password}`；Files Upload的File Path改为 `${cert_path}`，文件参数名仍为certificate。

下单场景的加购物车Body Data：`{"product_id":${product_id},"quantity":1}`。

每个线程固定使用一个账号：线程组外层Loop Count=1，CSV放在线程组下；登录初始化放在Once Only Controller中，重复业务放在内部Loop Controller中。不要在线程组外层反复循环并重新分配CSV账号。

先1线程1循环，再5线程短时验证。现有限流仍会限制持续压测；CSV数据准备不代表限流配置或性能测试已经完成。

证书检查记录见certificate-inventory.md。已确认文件存在、CN一致且在有效期内；未通过这些检查证明数据库中的角色、证书信任/吊销状态或密码有效，真实登录仍需联调确认。

含密码的users-local*.csv已加入本目录.gitignore。提交报告时使用脱敏模板，不直接上传真实账号数据。
