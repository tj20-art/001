// JSR223 PreProcessor, language=groovy, cache compiled script enabled.
// Attach only to an encrypted HTTP Request; Body Data must be a JSON object.
// Variables: tunnel_public_key (hex, from /api/v1/security/public-key).
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import java.security.SecureRandom
import java.nio.charset.StandardCharsets
import java.util.Arrays
import org.bouncycastle.asn1.gm.GMNamedCurves
import org.bouncycastle.crypto.engines.SM2Engine
import org.bouncycastle.crypto.engines.SM4Engine
import org.bouncycastle.crypto.modes.GCMBlockCipher
import org.bouncycastle.crypto.params.AEADParameters
import org.bouncycastle.crypto.params.ECDomainParameters
import org.bouncycastle.crypto.params.ECPublicKeyParameters
import org.bouncycastle.crypto.params.KeyParameter
import org.bouncycastle.crypto.params.ParametersWithRandom
import org.bouncycastle.util.encoders.Hex

def utf8 = StandardCharsets.UTF_8
def random = new SecureRandom()
def randomBytes = { int n -> byte[] b = new byte[n]; random.nextBytes(b); b }
def publicHex = vars.get('tunnel_public_key')
if (!publicHex) throw new IllegalStateException('Missing tunnel_public_key')
if (publicHex.length() == 128) publicHex = '04' + publicHex

// Keep templates in thread-local variables: JMeter restores sampler properties
// after sampling, including custom properties and the mutated argument list.
def templates = vars.getObject('perf_body_templates')
if (templates == null) {
    templates = [:]
    vars.putObject('perf_body_templates', templates)
}
def templateId = sampler.getName() + '\n' + sampler.getMethod() + '\n' + sampler.getPath()
def template = templates[templateId]
if (template == null) {
    if (sampler.getArguments().getArgumentCount() == 0) {
        throw new IllegalArgumentException('Encrypted HTTP Request needs JSON in Body Data')
    }
    template = sampler.getArguments().getArgument(0).getValue()
    templates[templateId] = template
}
def plaintext = new org.apache.jmeter.engine.util.CompoundVariable(template).execute()
def parsed = new JsonSlurper().parseText(plaintext)
if (!(parsed instanceof Map)) throw new IllegalArgumentException('Body Data must be a JSON object')
byte[] key = randomBytes(16)
byte[] iv = randomBytes(12)
def nonce = Hex.toHexString(randomBytes(16))
def requestId = Hex.toHexString(randomBytes(16))
long timestamp = System.currentTimeMillis()
def aad = (sampler.getMethod().toUpperCase() + '\n' + sampler.getUrl().getPath() + '\n' + timestamp + '\n' + nonce + '\n' + requestId).getBytes(utf8)
byte[] plainBytes = plaintext.getBytes(utf8)
def gcm = new GCMBlockCipher(new SM4Engine())
gcm.init(true, new AEADParameters(new KeyParameter(key), 128, iv, aad))
byte[] output = new byte[gcm.getOutputSize(plainBytes.length)]
int count = gcm.processBytes(plainBytes, 0, plainBytes.length, output, 0)
count += gcm.doFinal(output, count)

def curve = GMNamedCurves.getByName('sm2p256v1')
def domain = new ECDomainParameters(curve.getCurve(), curve.getG(), curve.getN(), curve.getH())
def publicKey = new ECPublicKeyParameters(curve.getCurve().decodePoint(Hex.decode(publicHex)), domain)
def sm2 = new SM2Engine(SM2Engine.Mode.C1C2C3)
sm2.init(true, new ParametersWithRandom(publicKey, random))
// Match sm-crypto: encrypt the ASCII hex key. gmssl omits the C1 04 prefix.
byte[] keyText = Hex.toHexString(key).getBytes(utf8)
byte[] wrapped = sm2.processBlock(keyText, 0, keyText.length)
def envelope = [version:'1', algorithm:'SM2+SM4-GCM',
    encrypted_key:Hex.toHexString(Arrays.copyOfRange(wrapped, 1, wrapped.length)),
    iv:Hex.toHexString(iv),
    ciphertext:Hex.toHexString(Arrays.copyOfRange(output, 0, count - 16)),
    tag:Hex.toHexString(Arrays.copyOfRange(output, count - 16, count)),
    nonce:nonce, timestamp:timestamp, request_id:requestId]
vars.putObject('perf_session_key', key)
vars.put('perf_request_id', requestId)
sampler.getArguments().removeAllArguments()
sampler.addNonEncodedArgument('', JsonOutput.toJson(envelope), '')
sampler.setPostBodyRaw(true)
