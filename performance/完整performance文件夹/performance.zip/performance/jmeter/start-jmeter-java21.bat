@echo off
setlocal
set "PERF_JAVA_HOME=D:\PyCharm Community Edition 2023.3.1\jbr"
set "PERF_JMETER_HOME=D:\Downloads\JMeter\apache-jmeter-5.6.3"
if not exist "%PERF_JAVA_HOME%\bin\java.exe" (
  echo Java runtime not found: %PERF_JAVA_HOME%
  pause
  exit /b 1
)
if not exist "%PERF_JMETER_HOME%\bin\jmeter.bat" (
  echo JMeter not found: %PERF_JMETER_HOME%
  pause
  exit /b 1
)
set "PATH=%PERF_JAVA_HOME%\bin;%PATH%"
set "JAVA_HOME=%PERF_JAVA_HOME%"
set "JM_LAUNCH=%PERF_JAVA_HOME%\bin\java.exe"
set "JMETER_HOME=%PERF_JMETER_HOME%"
set "JMETER_BIN=%PERF_JMETER_HOME%\bin\"
pushd "%PERF_JMETER_HOME%\bin"
call "%PERF_JMETER_HOME%\bin\jmeter.bat" %*
set "PERF_EXIT=%ERRORLEVEL%"
popd
endlocal & exit /b %PERF_EXIT%
