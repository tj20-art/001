# 第8、9周 JMeter 辅助脚本

这两个脚本依据当前项目的 security_tunnel.py 和 secureTunnel.js 编写，不修改后端业务代码。

前提：在 JMeter 的 lib 目录中有一个支持 SM2、SM4-GCM 的 bcprov-jdk18on JAR。若已有 bcprov，请先确认版本和可用算法，避免同时放入多个版本。官方来源：https://www.bouncycastle.org/download/bouncy-castle-java/ 。添加或更换 JAR 后重启 JMeter。

## 配置

1. 在线程开始时调用 GET /api/v1/security/public-key，用 JSON Extractor 把 $.data.public_key 保存为 tunnel_public_key。推荐放在 Once Only Controller 中。
2. 加入购物车 POST /api/v1/cart/items 的 Body Data 写入 {"product_id":${product_id},"quantity":1}。
3. 创建订单 POST /api/v1/orders 的 Body Data 写入 {}。
4. 在上述每一个 POST 请求下面分别添加：
   - HTTP Header Manager：Content-Type=application/json、X-Secure-Envelope=1、Authorization=Bearer ${access_token}。
   - JSR223 PreProcessor：Language=groovy，Filename 选择 seal-request.groovy。
   - JSR223 PostProcessor：Language=groovy，Filename 选择 open-response.groovy。
   - 勾选脚本编译缓存。不要把加密脚本挂在线程组上，否则登录和 GET 也会被加密。
5. 两个请求依次执行，购物车失败时不得继续下单。线程组遇错选择 Stop Thread。
6. 每个并发线程使用一个独立的普通用户账号；不得多个线程共享一个购物车。

登录是 multipart 的密码+证书，不能使用上述加密脚本。商品查询 GET 也不使用这两个脚本。

## 时间口径

JSR223 前处理和后处理在 HTTP Sampler 计时之外。本方案报告的是 HTTP 请求耗时，包含服务端解密、业务处理、响应加密和网络时间，不包含客户端加密、解密耗时。报告应写明这一点；如要测用户端完整耗时，应另设固定的事务计时并单独报告。

## 验证状态

2026-11-04：JMeter 日志确认 Java 24 + Groovy 3.0.20 在前处理器编译阶段报 Unsupported class file major version 68。使用 start-jmeter-java21.bat 可让本次 JMeter 进程使用电脑已有的 PyCharm JBR 21，不修改系统 Java 配置。

已使用本机 JMeter 类库、bcprov 1.86 和 JBR 21 进行离线验证：请求脚本编译通过、连续请求 Nonce 不同、当前 Python 后端协议函数能解密 Java 脚本生成的信封、响应脚本能解密 Python 后端生成的响应。没有执行真实登录、购物车写入或创建订单，也没有产生性能基线。仍需在 JMeter 界面以 1 线程、1 循环完成真实联调。
