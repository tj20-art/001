// JSR223 PostProcessor, language=groovy, cache enabled.
// Attach to the same HTTP Request as seal-request.groovy.
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import java.nio.charset.StandardCharsets
import org.bouncycastle.crypto.engines.SM4Engine
import org.bouncycastle.crypto.modes.GCMBlockCipher
import org.bouncycastle.crypto.params.AEADParameters
import org.bouncycastle.crypto.params.KeyParameter
import org.bouncycastle.util.encoders.Hex

try {
    def utf8 = StandardCharsets.UTF_8
    def envelope = new JsonSlurper().parseText(prev.getResponseDataAsString())
    if (envelope.algorithm != 'SM4-GCM') {
        prev.setSuccessful(false)
        prev.setResponseMessage('Expected encrypted response; inspect HTTP status and response body')
        return
    }
    def requestId = vars.get('perf_request_id')
    if (envelope.request_id != requestId) throw new IllegalStateException('Response request_id mismatch')
    byte[] key = (byte[])vars.getObject('perf_session_key')
    byte[] combined = Hex.decode(envelope.ciphertext.toString() + envelope.tag.toString())
    def gcm = new GCMBlockCipher(new SM4Engine())
    gcm.init(false, new AEADParameters(new KeyParameter(key), 128,
        Hex.decode(envelope.iv.toString()), ('RESPONSE\n' + requestId).getBytes(utf8)))
    byte[] output = new byte[gcm.getOutputSize(combined.length)]
    int count = gcm.processBytes(combined, 0, combined.length, output, 0)
    count += gcm.doFinal(output, count)
    def payload = new JsonSlurper().parseText(new String(output, 0, count, utf8))
    // HTTP elapsed timing is left intact. Make decrypted JSON available to assertions.
    prev.setResponseData(JsonOutput.toJson(payload), 'UTF-8')
    if (!(payload instanceof Map) || payload.code != 0) {
        prev.setSuccessful(false)
        prev.setResponseMessage('Business failure: ' + payload.message)
    }
} catch (Exception e) {
    prev.setSuccessful(false)
    prev.setResponseMessage('Secure response verification failed: ' + e.getClass().getSimpleName())
    log.error('Secure response verification failed', e)
}
