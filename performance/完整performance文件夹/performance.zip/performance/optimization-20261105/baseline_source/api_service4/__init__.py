# Isolate the measured package from the optimized workspace namespace.
