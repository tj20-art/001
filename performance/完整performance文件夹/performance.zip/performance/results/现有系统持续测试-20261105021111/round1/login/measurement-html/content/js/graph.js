/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 162.0, "minX": 0.0, "maxY": 1296.0, "series": [{"data": [[0.0, 162.0], [0.1, 165.0], [0.2, 173.0], [0.3, 191.0], [0.4, 194.0], [0.5, 197.0], [0.6, 200.0], [0.7, 202.0], [0.8, 203.0], [0.9, 204.0], [1.0, 205.0], [1.1, 206.0], [1.2, 208.0], [1.3, 208.0], [1.4, 209.0], [1.5, 211.0], [1.6, 212.0], [1.7, 213.0], [1.8, 213.0], [1.9, 214.0], [2.0, 214.0], [2.1, 215.0], [2.2, 216.0], [2.3, 216.0], [2.4, 217.0], [2.5, 218.0], [2.6, 219.0], [2.7, 219.0], [2.8, 219.0], [2.9, 219.0], [3.0, 220.0], [3.1, 221.0], [3.2, 221.0], [3.3, 222.0], [3.4, 222.0], [3.5, 223.0], [3.6, 223.0], [3.7, 223.0], [3.8, 224.0], [3.9, 224.0], [4.0, 224.0], [4.1, 224.0], [4.2, 225.0], [4.3, 225.0], [4.4, 225.0], [4.5, 225.0], [4.6, 226.0], [4.7, 226.0], [4.8, 226.0], [4.9, 226.0], [5.0, 227.0], [5.1, 227.0], [5.2, 227.0], [5.3, 227.0], [5.4, 227.0], [5.5, 227.0], [5.6, 228.0], [5.7, 228.0], [5.8, 228.0], [5.9, 228.0], [6.0, 229.0], [6.1, 229.0], [6.2, 229.0], [6.3, 229.0], [6.4, 229.0], [6.5, 229.0], [6.6, 230.0], [6.7, 230.0], [6.8, 230.0], [6.9, 230.0], [7.0, 230.0], [7.1, 230.0], [7.2, 231.0], [7.3, 231.0], [7.4, 231.0], [7.5, 231.0], [7.6, 231.0], [7.7, 232.0], [7.8, 232.0], [7.9, 232.0], [8.0, 232.0], [8.1, 232.0], [8.2, 232.0], [8.3, 232.0], [8.4, 233.0], [8.5, 233.0], [8.6, 233.0], [8.7, 233.0], [8.8, 233.0], [8.9, 233.0], [9.0, 233.0], [9.1, 233.0], [9.2, 233.0], [9.3, 233.0], [9.4, 234.0], [9.5, 234.0], [9.6, 234.0], [9.7, 234.0], [9.8, 234.0], [9.9, 235.0], [10.0, 235.0], [10.1, 235.0], [10.2, 235.0], [10.3, 235.0], [10.4, 235.0], [10.5, 236.0], [10.6, 236.0], [10.7, 236.0], [10.8, 236.0], [10.9, 236.0], [11.0, 236.0], [11.1, 236.0], [11.2, 237.0], [11.3, 237.0], [11.4, 237.0], [11.5, 237.0], [11.6, 237.0], [11.7, 237.0], [11.8, 237.0], [11.9, 237.0], [12.0, 238.0], [12.1, 238.0], [12.2, 238.0], [12.3, 238.0], [12.4, 238.0], [12.5, 238.0], [12.6, 238.0], [12.7, 238.0], [12.8, 239.0], [12.9, 239.0], [13.0, 239.0], [13.1, 239.0], [13.2, 239.0], [13.3, 239.0], [13.4, 239.0], [13.5, 239.0], [13.6, 240.0], [13.7, 240.0], [13.8, 240.0], [13.9, 240.0], [14.0, 241.0], [14.1, 241.0], [14.2, 241.0], [14.3, 241.0], [14.4, 241.0], [14.5, 241.0], [14.6, 241.0], [14.7, 241.0], [14.8, 242.0], [14.9, 242.0], [15.0, 242.0], [15.1, 242.0], [15.2, 242.0], [15.3, 242.0], [15.4, 242.0], [15.5, 243.0], [15.6, 243.0], [15.7, 243.0], [15.8, 243.0], [15.9, 243.0], [16.0, 243.0], [16.1, 244.0], [16.2, 244.0], [16.3, 244.0], [16.4, 244.0], [16.5, 244.0], [16.6, 244.0], [16.7, 244.0], [16.8, 244.0], [16.9, 244.0], [17.0, 244.0], [17.1, 245.0], [17.2, 245.0], [17.3, 245.0], [17.4, 245.0], [17.5, 245.0], [17.6, 245.0], [17.7, 245.0], [17.8, 245.0], [17.9, 245.0], [18.0, 245.0], [18.1, 245.0], [18.2, 245.0], [18.3, 245.0], [18.4, 245.0], [18.5, 245.0], [18.6, 246.0], [18.7, 246.0], [18.8, 246.0], [18.9, 246.0], [19.0, 246.0], [19.1, 246.0], [19.2, 246.0], [19.3, 246.0], [19.4, 246.0], [19.5, 246.0], [19.6, 246.0], [19.7, 246.0], [19.8, 246.0], [19.9, 247.0], [20.0, 247.0], [20.1, 247.0], [20.2, 247.0], [20.3, 247.0], [20.4, 247.0], [20.5, 247.0], [20.6, 247.0], [20.7, 248.0], [20.8, 248.0], [20.9, 248.0], [21.0, 248.0], [21.1, 248.0], [21.2, 248.0], [21.3, 248.0], [21.4, 248.0], [21.5, 249.0], [21.6, 249.0], [21.7, 249.0], [21.8, 249.0], [21.9, 249.0], [22.0, 249.0], [22.1, 249.0], [22.2, 249.0], [22.3, 249.0], [22.4, 249.0], [22.5, 249.0], [22.6, 250.0], [22.7, 250.0], [22.8, 250.0], [22.9, 250.0], [23.0, 250.0], [23.1, 250.0], [23.2, 250.0], [23.3, 251.0], [23.4, 251.0], [23.5, 251.0], [23.6, 251.0], [23.7, 251.0], [23.8, 251.0], [23.9, 251.0], [24.0, 251.0], [24.1, 252.0], [24.2, 252.0], [24.3, 252.0], [24.4, 252.0], [24.5, 252.0], [24.6, 252.0], [24.7, 252.0], [24.8, 252.0], [24.9, 252.0], [25.0, 253.0], [25.1, 253.0], [25.2, 253.0], [25.3, 253.0], [25.4, 253.0], [25.5, 253.0], [25.6, 253.0], [25.7, 253.0], [25.8, 253.0], [25.9, 253.0], [26.0, 254.0], [26.1, 254.0], [26.2, 254.0], [26.3, 254.0], [26.4, 254.0], [26.5, 254.0], [26.6, 254.0], [26.7, 255.0], [26.8, 255.0], [26.9, 255.0], [27.0, 255.0], [27.1, 255.0], [27.2, 255.0], [27.3, 255.0], [27.4, 255.0], [27.5, 255.0], [27.6, 255.0], [27.7, 255.0], [27.8, 256.0], [27.9, 256.0], [28.0, 256.0], [28.1, 256.0], [28.2, 256.0], [28.3, 256.0], [28.4, 256.0], [28.5, 256.0], [28.6, 257.0], [28.7, 257.0], [28.8, 257.0], [28.9, 257.0], [29.0, 257.0], [29.1, 257.0], [29.2, 257.0], [29.3, 257.0], [29.4, 258.0], [29.5, 258.0], [29.6, 258.0], [29.7, 258.0], [29.8, 258.0], [29.9, 258.0], [30.0, 258.0], [30.1, 258.0], [30.2, 258.0], [30.3, 259.0], [30.4, 259.0], [30.5, 259.0], [30.6, 259.0], [30.7, 259.0], [30.8, 259.0], [30.9, 259.0], [31.0, 259.0], [31.1, 259.0], [31.2, 259.0], [31.3, 260.0], [31.4, 260.0], [31.5, 260.0], [31.6, 260.0], [31.7, 260.0], [31.8, 261.0], [31.9, 261.0], [32.0, 261.0], [32.1, 261.0], [32.2, 261.0], [32.3, 261.0], [32.4, 261.0], [32.5, 261.0], [32.6, 261.0], [32.7, 262.0], [32.8, 262.0], [32.9, 262.0], [33.0, 262.0], [33.1, 263.0], [33.2, 263.0], [33.3, 263.0], [33.4, 263.0], [33.5, 263.0], [33.6, 263.0], [33.7, 263.0], [33.8, 263.0], [33.9, 263.0], [34.0, 264.0], [34.1, 264.0], [34.2, 264.0], [34.3, 264.0], [34.4, 264.0], [34.5, 265.0], [34.6, 265.0], [34.7, 265.0], [34.8, 265.0], [34.9, 265.0], [35.0, 265.0], [35.1, 265.0], [35.2, 266.0], [35.3, 266.0], [35.4, 266.0], [35.5, 266.0], [35.6, 266.0], [35.7, 266.0], [35.8, 266.0], [35.9, 266.0], [36.0, 267.0], [36.1, 267.0], [36.2, 267.0], [36.3, 267.0], [36.4, 267.0], [36.5, 267.0], [36.6, 267.0], [36.7, 268.0], [36.8, 268.0], [36.9, 268.0], [37.0, 269.0], [37.1, 269.0], [37.2, 269.0], [37.3, 269.0], [37.4, 269.0], [37.5, 269.0], [37.6, 270.0], [37.7, 271.0], [37.8, 271.0], [37.9, 271.0], [38.0, 271.0], [38.1, 271.0], [38.2, 271.0], [38.3, 271.0], [38.4, 271.0], [38.5, 271.0], [38.6, 272.0], [38.7, 272.0], [38.8, 272.0], [38.9, 272.0], [39.0, 272.0], [39.1, 272.0], [39.2, 272.0], [39.3, 272.0], [39.4, 273.0], [39.5, 273.0], [39.6, 273.0], [39.7, 273.0], [39.8, 274.0], [39.9, 274.0], [40.0, 274.0], [40.1, 274.0], [40.2, 274.0], [40.3, 274.0], [40.4, 275.0], [40.5, 275.0], [40.6, 275.0], [40.7, 275.0], [40.8, 275.0], [40.9, 275.0], [41.0, 275.0], [41.1, 276.0], [41.2, 276.0], [41.3, 276.0], [41.4, 276.0], [41.5, 277.0], [41.6, 277.0], [41.7, 277.0], [41.8, 277.0], [41.9, 277.0], [42.0, 277.0], [42.1, 278.0], [42.2, 278.0], [42.3, 278.0], [42.4, 278.0], [42.5, 279.0], [42.6, 279.0], [42.7, 279.0], [42.8, 279.0], [42.9, 280.0], [43.0, 280.0], [43.1, 280.0], [43.2, 281.0], [43.3, 281.0], [43.4, 281.0], [43.5, 282.0], [43.6, 282.0], [43.7, 282.0], [43.8, 283.0], [43.9, 283.0], [44.0, 284.0], [44.1, 284.0], [44.2, 284.0], [44.3, 284.0], [44.4, 285.0], [44.5, 285.0], [44.6, 285.0], [44.7, 285.0], [44.8, 286.0], [44.9, 286.0], [45.0, 286.0], [45.1, 286.0], [45.2, 287.0], [45.3, 287.0], [45.4, 288.0], [45.5, 288.0], [45.6, 288.0], [45.7, 288.0], [45.8, 288.0], [45.9, 289.0], [46.0, 289.0], [46.1, 290.0], [46.2, 290.0], [46.3, 290.0], [46.4, 290.0], [46.5, 291.0], [46.6, 291.0], [46.7, 291.0], [46.8, 291.0], [46.9, 292.0], [47.0, 293.0], [47.1, 293.0], [47.2, 294.0], [47.3, 294.0], [47.4, 294.0], [47.5, 294.0], [47.6, 294.0], [47.7, 295.0], [47.8, 295.0], [47.9, 296.0], [48.0, 297.0], [48.1, 297.0], [48.2, 298.0], [48.3, 298.0], [48.4, 298.0], [48.5, 299.0], [48.6, 299.0], [48.7, 299.0], [48.8, 300.0], [48.9, 301.0], [49.0, 302.0], [49.1, 302.0], [49.2, 302.0], [49.3, 302.0], [49.4, 303.0], [49.5, 305.0], [49.6, 305.0], [49.7, 306.0], [49.8, 306.0], [49.9, 306.0], [50.0, 307.0], [50.1, 310.0], [50.2, 311.0], [50.3, 314.0], [50.4, 314.0], [50.5, 316.0], [50.6, 317.0], [50.7, 318.0], [50.8, 319.0], [50.9, 320.0], [51.0, 320.0], [51.1, 321.0], [51.2, 323.0], [51.3, 323.0], [51.4, 324.0], [51.5, 326.0], [51.6, 327.0], [51.7, 328.0], [51.8, 330.0], [51.9, 331.0], [52.0, 333.0], [52.1, 334.0], [52.2, 335.0], [52.3, 336.0], [52.4, 337.0], [52.5, 339.0], [52.6, 339.0], [52.7, 341.0], [52.8, 341.0], [52.9, 344.0], [53.0, 347.0], [53.1, 347.0], [53.2, 349.0], [53.3, 350.0], [53.4, 352.0], [53.5, 354.0], [53.6, 355.0], [53.7, 356.0], [53.8, 357.0], [53.9, 358.0], [54.0, 359.0], [54.1, 359.0], [54.2, 360.0], [54.3, 361.0], [54.4, 362.0], [54.5, 362.0], [54.6, 362.0], [54.7, 363.0], [54.8, 363.0], [54.9, 364.0], [55.0, 366.0], [55.1, 369.0], [55.2, 369.0], [55.3, 371.0], [55.4, 372.0], [55.5, 373.0], [55.6, 374.0], [55.7, 376.0], [55.8, 376.0], [55.9, 377.0], [56.0, 378.0], [56.1, 379.0], [56.2, 380.0], [56.3, 380.0], [56.4, 381.0], [56.5, 382.0], [56.6, 383.0], [56.7, 386.0], [56.8, 387.0], [56.9, 388.0], [57.0, 389.0], [57.1, 392.0], [57.2, 395.0], [57.3, 397.0], [57.4, 398.0], [57.5, 399.0], [57.6, 400.0], [57.7, 401.0], [57.8, 402.0], [57.9, 405.0], [58.0, 406.0], [58.1, 408.0], [58.2, 409.0], [58.3, 410.0], [58.4, 411.0], [58.5, 413.0], [58.6, 418.0], [58.7, 420.0], [58.8, 421.0], [58.9, 425.0], [59.0, 428.0], [59.1, 430.0], [59.2, 432.0], [59.3, 435.0], [59.4, 436.0], [59.5, 437.0], [59.6, 438.0], [59.7, 439.0], [59.8, 442.0], [59.9, 443.0], [60.0, 445.0], [60.1, 446.0], [60.2, 447.0], [60.3, 448.0], [60.4, 450.0], [60.5, 453.0], [60.6, 454.0], [60.7, 456.0], [60.8, 456.0], [60.9, 457.0], [61.0, 459.0], [61.1, 459.0], [61.2, 460.0], [61.3, 461.0], [61.4, 465.0], [61.5, 466.0], [61.6, 469.0], [61.7, 470.0], [61.8, 471.0], [61.9, 472.0], [62.0, 473.0], [62.1, 474.0], [62.2, 476.0], [62.3, 481.0], [62.4, 483.0], [62.5, 483.0], [62.6, 485.0], [62.7, 486.0], [62.8, 486.0], [62.9, 488.0], [63.0, 489.0], [63.1, 490.0], [63.2, 490.0], [63.3, 492.0], [63.4, 493.0], [63.5, 494.0], [63.6, 495.0], [63.7, 496.0], [63.8, 497.0], [63.9, 498.0], [64.0, 498.0], [64.1, 499.0], [64.2, 500.0], [64.3, 500.0], [64.4, 501.0], [64.5, 503.0], [64.6, 504.0], [64.7, 505.0], [64.8, 507.0], [64.9, 509.0], [65.0, 509.0], [65.1, 510.0], [65.2, 512.0], [65.3, 512.0], [65.4, 513.0], [65.5, 513.0], [65.6, 514.0], [65.7, 516.0], [65.8, 516.0], [65.9, 517.0], [66.0, 520.0], [66.1, 521.0], [66.2, 521.0], [66.3, 522.0], [66.4, 523.0], [66.5, 525.0], [66.6, 526.0], [66.7, 526.0], [66.8, 527.0], [66.9, 528.0], [67.0, 528.0], [67.1, 530.0], [67.2, 531.0], [67.3, 531.0], [67.4, 532.0], [67.5, 533.0], [67.6, 534.0], [67.7, 534.0], [67.8, 536.0], [67.9, 536.0], [68.0, 536.0], [68.1, 537.0], [68.2, 537.0], [68.3, 538.0], [68.4, 539.0], [68.5, 540.0], [68.6, 542.0], [68.7, 542.0], [68.8, 544.0], [68.9, 545.0], [69.0, 545.0], [69.1, 545.0], [69.2, 546.0], [69.3, 547.0], [69.4, 547.0], [69.5, 549.0], [69.6, 550.0], [69.7, 551.0], [69.8, 552.0], [69.9, 553.0], [70.0, 555.0], [70.1, 556.0], [70.2, 557.0], [70.3, 558.0], [70.4, 558.0], [70.5, 558.0], [70.6, 559.0], [70.7, 560.0], [70.8, 560.0], [70.9, 561.0], [71.0, 561.0], [71.1, 561.0], [71.2, 562.0], [71.3, 563.0], [71.4, 563.0], [71.5, 565.0], [71.6, 565.0], [71.7, 566.0], [71.8, 567.0], [71.9, 567.0], [72.0, 567.0], [72.1, 568.0], [72.2, 569.0], [72.3, 570.0], [72.4, 571.0], [72.5, 571.0], [72.6, 573.0], [72.7, 574.0], [72.8, 575.0], [72.9, 577.0], [73.0, 578.0], [73.1, 578.0], [73.2, 579.0], [73.3, 579.0], [73.4, 579.0], [73.5, 580.0], [73.6, 581.0], [73.7, 581.0], [73.8, 582.0], [73.9, 582.0], [74.0, 582.0], [74.1, 584.0], [74.2, 585.0], [74.3, 585.0], [74.4, 587.0], [74.5, 587.0], [74.6, 588.0], [74.7, 589.0], [74.8, 590.0], [74.9, 591.0], [75.0, 592.0], [75.1, 592.0], [75.2, 593.0], [75.3, 593.0], [75.4, 594.0], [75.5, 594.0], [75.6, 596.0], [75.7, 597.0], [75.8, 598.0], [75.9, 599.0], [76.0, 599.0], [76.1, 601.0], [76.2, 601.0], [76.3, 602.0], [76.4, 602.0], [76.5, 602.0], [76.6, 603.0], [76.7, 603.0], [76.8, 604.0], [76.9, 604.0], [77.0, 606.0], [77.1, 607.0], [77.2, 607.0], [77.3, 607.0], [77.4, 607.0], [77.5, 609.0], [77.6, 609.0], [77.7, 610.0], [77.8, 610.0], [77.9, 611.0], [78.0, 611.0], [78.1, 611.0], [78.2, 612.0], [78.3, 613.0], [78.4, 613.0], [78.5, 613.0], [78.6, 614.0], [78.7, 615.0], [78.8, 615.0], [78.9, 615.0], [79.0, 616.0], [79.1, 616.0], [79.2, 617.0], [79.3, 617.0], [79.4, 617.0], [79.5, 618.0], [79.6, 618.0], [79.7, 619.0], [79.8, 620.0], [79.9, 621.0], [80.0, 622.0], [80.1, 622.0], [80.2, 623.0], [80.3, 623.0], [80.4, 624.0], [80.5, 624.0], [80.6, 624.0], [80.7, 625.0], [80.8, 625.0], [80.9, 626.0], [81.0, 626.0], [81.1, 626.0], [81.2, 627.0], [81.3, 627.0], [81.4, 628.0], [81.5, 629.0], [81.6, 629.0], [81.7, 630.0], [81.8, 630.0], [81.9, 630.0], [82.0, 630.0], [82.1, 631.0], [82.2, 631.0], [82.3, 631.0], [82.4, 632.0], [82.5, 633.0], [82.6, 633.0], [82.7, 634.0], [82.8, 634.0], [82.9, 635.0], [83.0, 635.0], [83.1, 636.0], [83.2, 636.0], [83.3, 636.0], [83.4, 636.0], [83.5, 637.0], [83.6, 637.0], [83.7, 638.0], [83.8, 638.0], [83.9, 639.0], [84.0, 640.0], [84.1, 640.0], [84.2, 641.0], [84.3, 641.0], [84.4, 642.0], [84.5, 643.0], [84.6, 643.0], [84.7, 644.0], [84.8, 645.0], [84.9, 645.0], [85.0, 645.0], [85.1, 646.0], [85.2, 646.0], [85.3, 647.0], [85.4, 647.0], [85.5, 647.0], [85.6, 648.0], [85.7, 649.0], [85.8, 650.0], [85.9, 651.0], [86.0, 651.0], [86.1, 651.0], [86.2, 652.0], [86.3, 652.0], [86.4, 653.0], [86.5, 653.0], [86.6, 654.0], [86.7, 654.0], [86.8, 654.0], [86.9, 656.0], [87.0, 656.0], [87.1, 657.0], [87.2, 657.0], [87.3, 657.0], [87.4, 657.0], [87.5, 658.0], [87.6, 658.0], [87.7, 659.0], [87.8, 660.0], [87.9, 660.0], [88.0, 660.0], [88.1, 662.0], [88.2, 662.0], [88.3, 663.0], [88.4, 664.0], [88.5, 665.0], [88.6, 665.0], [88.7, 666.0], [88.8, 668.0], [88.9, 669.0], [89.0, 669.0], [89.1, 669.0], [89.2, 671.0], [89.3, 672.0], [89.4, 672.0], [89.5, 673.0], [89.6, 674.0], [89.7, 674.0], [89.8, 675.0], [89.9, 676.0], [90.0, 676.0], [90.1, 677.0], [90.2, 677.0], [90.3, 678.0], [90.4, 679.0], [90.5, 679.0], [90.6, 681.0], [90.7, 682.0], [90.8, 684.0], [90.9, 685.0], [91.0, 686.0], [91.1, 686.0], [91.2, 688.0], [91.3, 688.0], [91.4, 689.0], [91.5, 690.0], [91.6, 691.0], [91.7, 694.0], [91.8, 694.0], [91.9, 695.0], [92.0, 696.0], [92.1, 697.0], [92.2, 698.0], [92.3, 699.0], [92.4, 699.0], [92.5, 701.0], [92.6, 703.0], [92.7, 703.0], [92.8, 705.0], [92.9, 706.0], [93.0, 708.0], [93.1, 711.0], [93.2, 712.0], [93.3, 713.0], [93.4, 713.0], [93.5, 717.0], [93.6, 717.0], [93.7, 719.0], [93.8, 720.0], [93.9, 722.0], [94.0, 725.0], [94.1, 730.0], [94.2, 731.0], [94.3, 732.0], [94.4, 737.0], [94.5, 739.0], [94.6, 739.0], [94.7, 740.0], [94.8, 742.0], [94.9, 742.0], [95.0, 744.0], [95.1, 746.0], [95.2, 748.0], [95.3, 749.0], [95.4, 750.0], [95.5, 750.0], [95.6, 750.0], [95.7, 754.0], [95.8, 756.0], [95.9, 757.0], [96.0, 757.0], [96.1, 758.0], [96.2, 760.0], [96.3, 762.0], [96.4, 765.0], [96.5, 767.0], [96.6, 769.0], [96.7, 771.0], [96.8, 774.0], [96.9, 777.0], [97.0, 779.0], [97.1, 785.0], [97.2, 787.0], [97.3, 789.0], [97.4, 797.0], [97.5, 799.0], [97.6, 801.0], [97.7, 805.0], [97.8, 808.0], [97.9, 810.0], [98.0, 814.0], [98.1, 825.0], [98.2, 828.0], [98.3, 938.0], [98.4, 950.0], [98.5, 957.0], [98.6, 964.0], [98.7, 987.0], [98.8, 992.0], [98.9, 998.0], [99.0, 1007.0], [99.1, 1010.0], [99.2, 1015.0], [99.3, 1032.0], [99.4, 1053.0], [99.5, 1082.0], [99.6, 1241.0], [99.7, 1248.0], [99.8, 1264.0], [99.9, 1270.0]], "isOverall": false, "label": "01_普通用户登录", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 9.0, "minX": 100.0, "maxY": 911.0, "series": [{"data": [[600.0, 311.0], [300.0, 166.0], [1200.0, 9.0], [700.0, 95.0], [200.0, 911.0], [400.0, 125.0], [100.0, 11.0], [800.0, 14.0], [900.0, 13.0], [500.0, 224.0], [1000.0, 11.0]], "isOverall": false, "label": "01_普通用户登录", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 1200.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 674.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 1216.0, "series": [{"data": [[0.0, 1216.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 674.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 1.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 9.0, "minX": 1.79381682E12, "maxY": 9.0, "series": [{"data": [[1.793817E12, 9.0], [1.79381682E12, 9.0], [1.79381712E12, 9.0], [1.79381694E12, 9.0], [1.79381706E12, 9.0], [1.79381688E12, 9.0]], "isOverall": false, "label": "登录线程组", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79381712E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 417.24973544973534, "minX": 9.0, "maxY": 417.24973544973534, "series": [{"data": [[9.0, 417.24973544973534]], "isOverall": false, "label": "01_普通用户登录", "isController": false}, {"data": [[9.0, 417.24973544973534]], "isOverall": false, "label": "01_普通用户登录-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 9.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 2946.5833333333335, "minX": 1.79381682E12, "maxY": 8306.95, "series": [{"data": [[1.793817E12, 6358.416666666667], [1.79381682E12, 3566.9166666666665], [1.79381712E12, 2946.5833333333335], [1.79381694E12, 6547.966666666666], [1.79381706E12, 6513.5], [1.79381688E12, 6634.116666666667]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.793817E12, 7963.566666666667], [1.79381682E12, 4465.166666666667], [1.79381712E12, 3691.4333333333334], [1.79381694E12, 8206.083333333334], [1.79381706E12, 8156.133333333333], [1.79381688E12, 8306.95]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79381712E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 383.6900584795323, "minX": 1.79381682E12, "maxY": 446.4173441734414, "series": [{"data": [[1.793817E12, 446.4173441734414], [1.79381682E12, 434.3140096618356], [1.79381712E12, 383.6900584795323], [1.79381694E12, 414.32105263157865], [1.79381706E12, 421.21957671957676], [1.79381688E12, 394.0181818181817]], "isOverall": false, "label": "01_普通用户登录", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79381712E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 383.34502923976623, "minX": 1.79381682E12, "maxY": 446.040650406504, "series": [{"data": [[1.793817E12, 446.040650406504], [1.79381682E12, 433.87439613526567], [1.79381712E12, 383.34502923976623], [1.79381694E12, 413.8947368421052], [1.79381706E12, 420.8888888888891], [1.79381688E12, 393.6233766233766]], "isOverall": false, "label": "01_普通用户登录", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79381712E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 4.57309941520468, "minX": 1.79381682E12, "maxY": 5.782608695652177, "series": [{"data": [[1.793817E12, 5.6937669376693805], [1.79381682E12, 5.782608695652177], [1.79381712E12, 4.57309941520468], [1.79381694E12, 5.642105263157894], [1.79381706E12, 5.394179894179894], [1.79381688E12, 5.020779220779228]], "isOverall": false, "label": "01_普通用户登录", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79381712E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 162.0, "minX": 1.79381682E12, "maxY": 1296.0, "series": [{"data": [[1.793817E12, 1082.0], [1.79381682E12, 1296.0], [1.79381712E12, 797.0], [1.79381694E12, 1015.0], [1.79381706E12, 814.0], [1.79381688E12, 946.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.793817E12, 194.0], [1.79381682E12, 215.0], [1.79381712E12, 202.0], [1.79381694E12, 202.0], [1.79381706E12, 170.0], [1.79381688E12, 162.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.793817E12, 754.0], [1.79381682E12, 647.0000000000001], [1.79381712E12, 718.6], [1.79381694E12, 659.0], [1.79381706E12, 658.3000000000001], [1.79381688E12, 689.2]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.793817E12, 1043.9], [1.79381682E12, 1269.76], [1.79381712E12, 789.8], [1.79381694E12, 1004.5699999999999], [1.79381706E12, 774.21], [1.79381688E12, 782.6599999999997]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.793817E12, 323.0], [1.79381682E12, 386.0], [1.79381712E12, 261.0], [1.79381694E12, 289.5], [1.79381706E12, 376.0], [1.79381688E12, 282.0]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.793817E12, 812.0], [1.79381682E12, 707.7999999999998], [1.79381712E12, 743.2], [1.79381694E12, 688.95], [1.79381706E12, 696.45], [1.79381688E12, 746.7]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79381712E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 221.0, "minX": 1.0, "maxY": 677.0, "series": [{"data": [[4.0, 247.5], [8.0, 248.0], [1.0, 221.0], [2.0, 563.0], [9.0, 333.0], [5.0, 248.5], [6.0, 256.5], [3.0, 243.5], [7.0, 677.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 9.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 221.0, "minX": 1.0, "maxY": 677.0, "series": [{"data": [[4.0, 247.5], [8.0, 248.0], [1.0, 221.0], [2.0, 562.5], [9.0, 332.5], [5.0, 248.5], [6.0, 255.5], [3.0, 243.0], [7.0, 677.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 9.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 2.85, "minX": 1.79381682E12, "maxY": 6.45, "series": [{"data": [[1.793817E12, 6.15], [1.79381682E12, 3.45], [1.79381712E12, 2.85], [1.79381694E12, 6.3], [1.79381706E12, 6.3], [1.79381688E12, 6.45]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79381712E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 2.85, "minX": 1.79381682E12, "maxY": 6.416666666666667, "series": [{"data": [[1.793817E12, 6.15], [1.79381682E12, 3.45], [1.79381712E12, 2.85], [1.79381694E12, 6.333333333333333], [1.79381706E12, 6.3], [1.79381688E12, 6.416666666666667]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79381712E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 2.85, "minX": 1.79381682E12, "maxY": 6.416666666666667, "series": [{"data": [[1.793817E12, 6.15], [1.79381682E12, 3.45], [1.79381712E12, 2.85], [1.79381694E12, 6.333333333333333], [1.79381706E12, 6.3], [1.79381688E12, 6.416666666666667]], "isOverall": false, "label": "01_普通用户登录-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79381712E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 2.85, "minX": 1.79381682E12, "maxY": 6.416666666666667, "series": [{"data": [[1.793817E12, 6.15], [1.79381682E12, 3.45], [1.79381712E12, 2.85], [1.79381694E12, 6.333333333333333], [1.79381706E12, 6.3], [1.79381688E12, 6.416666666666667]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79381712E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

