/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 188.0, "minX": 0.0, "maxY": 1296.0, "series": [{"data": [[0.0, 188.0], [0.1, 190.0], [0.2, 192.0], [0.3, 193.0], [0.4, 198.0], [0.5, 201.0], [0.6, 203.0], [0.7, 204.0], [0.8, 204.0], [0.9, 206.0], [1.0, 209.0], [1.1, 211.0], [1.2, 212.0], [1.3, 212.0], [1.4, 213.0], [1.5, 214.0], [1.6, 214.0], [1.7, 216.0], [1.8, 217.0], [1.9, 218.0], [2.0, 219.0], [2.1, 220.0], [2.2, 221.0], [2.3, 222.0], [2.4, 222.0], [2.5, 223.0], [2.6, 223.0], [2.7, 223.0], [2.8, 224.0], [2.9, 225.0], [3.0, 226.0], [3.1, 226.0], [3.2, 226.0], [3.3, 226.0], [3.4, 227.0], [3.5, 227.0], [3.6, 227.0], [3.7, 228.0], [3.8, 228.0], [3.9, 228.0], [4.0, 228.0], [4.1, 229.0], [4.2, 229.0], [4.3, 229.0], [4.4, 229.0], [4.5, 230.0], [4.6, 230.0], [4.7, 231.0], [4.8, 231.0], [4.9, 232.0], [5.0, 232.0], [5.1, 232.0], [5.2, 232.0], [5.3, 232.0], [5.4, 232.0], [5.5, 232.0], [5.6, 233.0], [5.7, 233.0], [5.8, 233.0], [5.9, 233.0], [6.0, 233.0], [6.1, 233.0], [6.2, 234.0], [6.3, 234.0], [6.4, 234.0], [6.5, 235.0], [6.6, 235.0], [6.7, 235.0], [6.8, 235.0], [6.9, 236.0], [7.0, 236.0], [7.1, 236.0], [7.2, 236.0], [7.3, 236.0], [7.4, 237.0], [7.5, 237.0], [7.6, 237.0], [7.7, 237.0], [7.8, 237.0], [7.9, 237.0], [8.0, 237.0], [8.1, 237.0], [8.2, 237.0], [8.3, 238.0], [8.4, 238.0], [8.5, 238.0], [8.6, 238.0], [8.7, 238.0], [8.8, 238.0], [8.9, 238.0], [9.0, 239.0], [9.1, 239.0], [9.2, 239.0], [9.3, 239.0], [9.4, 239.0], [9.5, 239.0], [9.6, 240.0], [9.7, 240.0], [9.8, 240.0], [9.9, 240.0], [10.0, 241.0], [10.1, 241.0], [10.2, 241.0], [10.3, 241.0], [10.4, 241.0], [10.5, 241.0], [10.6, 242.0], [10.7, 242.0], [10.8, 242.0], [10.9, 242.0], [11.0, 242.0], [11.1, 242.0], [11.2, 242.0], [11.3, 242.0], [11.4, 242.0], [11.5, 242.0], [11.6, 243.0], [11.7, 243.0], [11.8, 243.0], [11.9, 243.0], [12.0, 243.0], [12.1, 243.0], [12.2, 243.0], [12.3, 244.0], [12.4, 244.0], [12.5, 244.0], [12.6, 244.0], [12.7, 244.0], [12.8, 244.0], [12.9, 245.0], [13.0, 245.0], [13.1, 245.0], [13.2, 245.0], [13.3, 245.0], [13.4, 245.0], [13.5, 245.0], [13.6, 246.0], [13.7, 246.0], [13.8, 246.0], [13.9, 246.0], [14.0, 246.0], [14.1, 246.0], [14.2, 246.0], [14.3, 246.0], [14.4, 246.0], [14.5, 247.0], [14.6, 247.0], [14.7, 247.0], [14.8, 247.0], [14.9, 247.0], [15.0, 247.0], [15.1, 247.0], [15.2, 247.0], [15.3, 247.0], [15.4, 247.0], [15.5, 248.0], [15.6, 248.0], [15.7, 248.0], [15.8, 248.0], [15.9, 248.0], [16.0, 248.0], [16.1, 249.0], [16.2, 249.0], [16.3, 249.0], [16.4, 249.0], [16.5, 249.0], [16.6, 249.0], [16.7, 249.0], [16.8, 249.0], [16.9, 249.0], [17.0, 249.0], [17.1, 249.0], [17.2, 250.0], [17.3, 250.0], [17.4, 250.0], [17.5, 250.0], [17.6, 250.0], [17.7, 250.0], [17.8, 250.0], [17.9, 250.0], [18.0, 251.0], [18.1, 251.0], [18.2, 251.0], [18.3, 251.0], [18.4, 251.0], [18.5, 252.0], [18.6, 252.0], [18.7, 252.0], [18.8, 252.0], [18.9, 252.0], [19.0, 252.0], [19.1, 252.0], [19.2, 253.0], [19.3, 253.0], [19.4, 253.0], [19.5, 253.0], [19.6, 253.0], [19.7, 253.0], [19.8, 253.0], [19.9, 253.0], [20.0, 254.0], [20.1, 254.0], [20.2, 254.0], [20.3, 254.0], [20.4, 254.0], [20.5, 254.0], [20.6, 255.0], [20.7, 255.0], [20.8, 255.0], [20.9, 255.0], [21.0, 255.0], [21.1, 255.0], [21.2, 255.0], [21.3, 255.0], [21.4, 256.0], [21.5, 256.0], [21.6, 256.0], [21.7, 256.0], [21.8, 256.0], [21.9, 256.0], [22.0, 256.0], [22.1, 256.0], [22.2, 257.0], [22.3, 257.0], [22.4, 257.0], [22.5, 257.0], [22.6, 257.0], [22.7, 257.0], [22.8, 257.0], [22.9, 257.0], [23.0, 257.0], [23.1, 257.0], [23.2, 257.0], [23.3, 258.0], [23.4, 258.0], [23.5, 258.0], [23.6, 258.0], [23.7, 258.0], [23.8, 258.0], [23.9, 258.0], [24.0, 258.0], [24.1, 259.0], [24.2, 259.0], [24.3, 259.0], [24.4, 259.0], [24.5, 259.0], [24.6, 260.0], [24.7, 260.0], [24.8, 260.0], [24.9, 260.0], [25.0, 260.0], [25.1, 260.0], [25.2, 260.0], [25.3, 260.0], [25.4, 260.0], [25.5, 261.0], [25.6, 261.0], [25.7, 261.0], [25.8, 261.0], [25.9, 261.0], [26.0, 261.0], [26.1, 261.0], [26.2, 261.0], [26.3, 262.0], [26.4, 262.0], [26.5, 262.0], [26.6, 262.0], [26.7, 262.0], [26.8, 262.0], [26.9, 263.0], [27.0, 263.0], [27.1, 263.0], [27.2, 263.0], [27.3, 263.0], [27.4, 263.0], [27.5, 264.0], [27.6, 264.0], [27.7, 264.0], [27.8, 264.0], [27.9, 264.0], [28.0, 264.0], [28.1, 264.0], [28.2, 264.0], [28.3, 264.0], [28.4, 265.0], [28.5, 265.0], [28.6, 265.0], [28.7, 265.0], [28.8, 265.0], [28.9, 266.0], [29.0, 266.0], [29.1, 266.0], [29.2, 266.0], [29.3, 266.0], [29.4, 267.0], [29.5, 267.0], [29.6, 267.0], [29.7, 267.0], [29.8, 267.0], [29.9, 267.0], [30.0, 267.0], [30.1, 267.0], [30.2, 268.0], [30.3, 268.0], [30.4, 268.0], [30.5, 268.0], [30.6, 268.0], [30.7, 269.0], [30.8, 269.0], [30.9, 269.0], [31.0, 269.0], [31.1, 270.0], [31.2, 270.0], [31.3, 270.0], [31.4, 270.0], [31.5, 270.0], [31.6, 270.0], [31.7, 271.0], [31.8, 271.0], [31.9, 271.0], [32.0, 272.0], [32.1, 272.0], [32.2, 272.0], [32.3, 272.0], [32.4, 273.0], [32.5, 273.0], [32.6, 273.0], [32.7, 273.0], [32.8, 273.0], [32.9, 274.0], [33.0, 274.0], [33.1, 274.0], [33.2, 274.0], [33.3, 274.0], [33.4, 274.0], [33.5, 274.0], [33.6, 274.0], [33.7, 274.0], [33.8, 275.0], [33.9, 275.0], [34.0, 275.0], [34.1, 275.0], [34.2, 275.0], [34.3, 275.0], [34.4, 276.0], [34.5, 276.0], [34.6, 276.0], [34.7, 277.0], [34.8, 277.0], [34.9, 277.0], [35.0, 277.0], [35.1, 278.0], [35.2, 278.0], [35.3, 278.0], [35.4, 278.0], [35.5, 279.0], [35.6, 279.0], [35.7, 280.0], [35.8, 280.0], [35.9, 280.0], [36.0, 280.0], [36.1, 280.0], [36.2, 280.0], [36.3, 281.0], [36.4, 281.0], [36.5, 282.0], [36.6, 282.0], [36.7, 282.0], [36.8, 283.0], [36.9, 283.0], [37.0, 284.0], [37.1, 284.0], [37.2, 284.0], [37.3, 284.0], [37.4, 285.0], [37.5, 285.0], [37.6, 285.0], [37.7, 286.0], [37.8, 286.0], [37.9, 287.0], [38.0, 287.0], [38.1, 287.0], [38.2, 288.0], [38.3, 288.0], [38.4, 289.0], [38.5, 289.0], [38.6, 289.0], [38.7, 290.0], [38.8, 291.0], [38.9, 291.0], [39.0, 291.0], [39.1, 291.0], [39.2, 292.0], [39.3, 293.0], [39.4, 293.0], [39.5, 293.0], [39.6, 294.0], [39.7, 294.0], [39.8, 294.0], [39.9, 294.0], [40.0, 294.0], [40.1, 295.0], [40.2, 295.0], [40.3, 296.0], [40.4, 296.0], [40.5, 297.0], [40.6, 297.0], [40.7, 297.0], [40.8, 298.0], [40.9, 298.0], [41.0, 299.0], [41.1, 299.0], [41.2, 301.0], [41.3, 301.0], [41.4, 302.0], [41.5, 302.0], [41.6, 302.0], [41.7, 302.0], [41.8, 303.0], [41.9, 304.0], [42.0, 305.0], [42.1, 305.0], [42.2, 305.0], [42.3, 305.0], [42.4, 306.0], [42.5, 306.0], [42.6, 307.0], [42.7, 308.0], [42.8, 308.0], [42.9, 309.0], [43.0, 309.0], [43.1, 310.0], [43.2, 310.0], [43.3, 311.0], [43.4, 311.0], [43.5, 313.0], [43.6, 314.0], [43.7, 314.0], [43.8, 315.0], [43.9, 316.0], [44.0, 318.0], [44.1, 318.0], [44.2, 319.0], [44.3, 319.0], [44.4, 320.0], [44.5, 320.0], [44.6, 320.0], [44.7, 321.0], [44.8, 322.0], [44.9, 323.0], [45.0, 323.0], [45.1, 324.0], [45.2, 324.0], [45.3, 325.0], [45.4, 325.0], [45.5, 325.0], [45.6, 325.0], [45.7, 327.0], [45.8, 327.0], [45.9, 328.0], [46.0, 329.0], [46.1, 329.0], [46.2, 330.0], [46.3, 330.0], [46.4, 331.0], [46.5, 332.0], [46.6, 332.0], [46.7, 334.0], [46.8, 335.0], [46.9, 335.0], [47.0, 336.0], [47.1, 337.0], [47.2, 338.0], [47.3, 339.0], [47.4, 340.0], [47.5, 341.0], [47.6, 343.0], [47.7, 343.0], [47.8, 343.0], [47.9, 344.0], [48.0, 346.0], [48.1, 346.0], [48.2, 347.0], [48.3, 349.0], [48.4, 349.0], [48.5, 350.0], [48.6, 350.0], [48.7, 350.0], [48.8, 350.0], [48.9, 351.0], [49.0, 352.0], [49.1, 352.0], [49.2, 353.0], [49.3, 353.0], [49.4, 354.0], [49.5, 354.0], [49.6, 355.0], [49.7, 355.0], [49.8, 357.0], [49.9, 357.0], [50.0, 357.0], [50.1, 358.0], [50.2, 358.0], [50.3, 359.0], [50.4, 361.0], [50.5, 364.0], [50.6, 365.0], [50.7, 365.0], [50.8, 365.0], [50.9, 365.0], [51.0, 366.0], [51.1, 368.0], [51.2, 369.0], [51.3, 371.0], [51.4, 371.0], [51.5, 372.0], [51.6, 372.0], [51.7, 373.0], [51.8, 376.0], [51.9, 376.0], [52.0, 376.0], [52.1, 378.0], [52.2, 379.0], [52.3, 380.0], [52.4, 381.0], [52.5, 382.0], [52.6, 383.0], [52.7, 384.0], [52.8, 386.0], [52.9, 388.0], [53.0, 389.0], [53.1, 391.0], [53.2, 393.0], [53.3, 393.0], [53.4, 395.0], [53.5, 397.0], [53.6, 398.0], [53.7, 399.0], [53.8, 403.0], [53.9, 403.0], [54.0, 403.0], [54.1, 405.0], [54.2, 406.0], [54.3, 406.0], [54.4, 408.0], [54.5, 410.0], [54.6, 410.0], [54.7, 411.0], [54.8, 413.0], [54.9, 415.0], [55.0, 417.0], [55.1, 418.0], [55.2, 419.0], [55.3, 421.0], [55.4, 422.0], [55.5, 422.0], [55.6, 424.0], [55.7, 424.0], [55.8, 426.0], [55.9, 426.0], [56.0, 427.0], [56.1, 428.0], [56.2, 429.0], [56.3, 430.0], [56.4, 431.0], [56.5, 431.0], [56.6, 432.0], [56.7, 432.0], [56.8, 435.0], [56.9, 437.0], [57.0, 438.0], [57.1, 438.0], [57.2, 439.0], [57.3, 440.0], [57.4, 441.0], [57.5, 441.0], [57.6, 442.0], [57.7, 443.0], [57.8, 444.0], [57.9, 444.0], [58.0, 444.0], [58.1, 445.0], [58.2, 445.0], [58.3, 446.0], [58.4, 448.0], [58.5, 449.0], [58.6, 450.0], [58.7, 451.0], [58.8, 451.0], [58.9, 452.0], [59.0, 454.0], [59.1, 455.0], [59.2, 455.0], [59.3, 459.0], [59.4, 459.0], [59.5, 460.0], [59.6, 461.0], [59.7, 463.0], [59.8, 463.0], [59.9, 465.0], [60.0, 466.0], [60.1, 467.0], [60.2, 468.0], [60.3, 471.0], [60.4, 471.0], [60.5, 473.0], [60.6, 473.0], [60.7, 474.0], [60.8, 474.0], [60.9, 475.0], [61.0, 476.0], [61.1, 476.0], [61.2, 477.0], [61.3, 478.0], [61.4, 478.0], [61.5, 479.0], [61.6, 479.0], [61.7, 481.0], [61.8, 481.0], [61.9, 482.0], [62.0, 484.0], [62.1, 485.0], [62.2, 486.0], [62.3, 487.0], [62.4, 489.0], [62.5, 490.0], [62.6, 491.0], [62.7, 492.0], [62.8, 492.0], [62.9, 493.0], [63.0, 494.0], [63.1, 495.0], [63.2, 495.0], [63.3, 497.0], [63.4, 498.0], [63.5, 499.0], [63.6, 500.0], [63.7, 501.0], [63.8, 503.0], [63.9, 504.0], [64.0, 506.0], [64.1, 506.0], [64.2, 508.0], [64.3, 509.0], [64.4, 509.0], [64.5, 510.0], [64.6, 511.0], [64.7, 512.0], [64.8, 513.0], [64.9, 515.0], [65.0, 517.0], [65.1, 517.0], [65.2, 518.0], [65.3, 518.0], [65.4, 520.0], [65.5, 520.0], [65.6, 522.0], [65.7, 523.0], [65.8, 525.0], [65.9, 526.0], [66.0, 528.0], [66.1, 528.0], [66.2, 529.0], [66.3, 529.0], [66.4, 529.0], [66.5, 529.0], [66.6, 530.0], [66.7, 531.0], [66.8, 531.0], [66.9, 532.0], [67.0, 532.0], [67.1, 534.0], [67.2, 535.0], [67.3, 536.0], [67.4, 537.0], [67.5, 538.0], [67.6, 539.0], [67.7, 540.0], [67.8, 541.0], [67.9, 543.0], [68.0, 545.0], [68.1, 546.0], [68.2, 547.0], [68.3, 548.0], [68.4, 548.0], [68.5, 549.0], [68.6, 549.0], [68.7, 549.0], [68.8, 549.0], [68.9, 551.0], [69.0, 552.0], [69.1, 553.0], [69.2, 554.0], [69.3, 555.0], [69.4, 556.0], [69.5, 556.0], [69.6, 557.0], [69.7, 557.0], [69.8, 558.0], [69.9, 558.0], [70.0, 559.0], [70.1, 560.0], [70.2, 561.0], [70.3, 563.0], [70.4, 563.0], [70.5, 563.0], [70.6, 565.0], [70.7, 566.0], [70.8, 566.0], [70.9, 567.0], [71.0, 568.0], [71.1, 568.0], [71.2, 569.0], [71.3, 569.0], [71.4, 570.0], [71.5, 570.0], [71.6, 572.0], [71.7, 572.0], [71.8, 574.0], [71.9, 574.0], [72.0, 575.0], [72.1, 576.0], [72.2, 577.0], [72.3, 580.0], [72.4, 581.0], [72.5, 581.0], [72.6, 582.0], [72.7, 585.0], [72.8, 586.0], [72.9, 586.0], [73.0, 588.0], [73.1, 589.0], [73.2, 590.0], [73.3, 590.0], [73.4, 591.0], [73.5, 592.0], [73.6, 592.0], [73.7, 592.0], [73.8, 593.0], [73.9, 593.0], [74.0, 594.0], [74.1, 595.0], [74.2, 596.0], [74.3, 596.0], [74.4, 597.0], [74.5, 597.0], [74.6, 598.0], [74.7, 599.0], [74.8, 600.0], [74.9, 600.0], [75.0, 602.0], [75.1, 602.0], [75.2, 604.0], [75.3, 606.0], [75.4, 607.0], [75.5, 608.0], [75.6, 609.0], [75.7, 609.0], [75.8, 609.0], [75.9, 610.0], [76.0, 611.0], [76.1, 612.0], [76.2, 612.0], [76.3, 612.0], [76.4, 613.0], [76.5, 614.0], [76.6, 614.0], [76.7, 615.0], [76.8, 615.0], [76.9, 616.0], [77.0, 616.0], [77.1, 617.0], [77.2, 618.0], [77.3, 618.0], [77.4, 618.0], [77.5, 619.0], [77.6, 619.0], [77.7, 619.0], [77.8, 620.0], [77.9, 620.0], [78.0, 622.0], [78.1, 622.0], [78.2, 622.0], [78.3, 623.0], [78.4, 624.0], [78.5, 624.0], [78.6, 625.0], [78.7, 626.0], [78.8, 627.0], [78.9, 629.0], [79.0, 629.0], [79.1, 630.0], [79.2, 630.0], [79.3, 631.0], [79.4, 631.0], [79.5, 634.0], [79.6, 634.0], [79.7, 634.0], [79.8, 635.0], [79.9, 635.0], [80.0, 636.0], [80.1, 636.0], [80.2, 636.0], [80.3, 637.0], [80.4, 637.0], [80.5, 638.0], [80.6, 638.0], [80.7, 638.0], [80.8, 639.0], [80.9, 640.0], [81.0, 640.0], [81.1, 640.0], [81.2, 641.0], [81.3, 641.0], [81.4, 641.0], [81.5, 641.0], [81.6, 642.0], [81.7, 642.0], [81.8, 642.0], [81.9, 643.0], [82.0, 644.0], [82.1, 645.0], [82.2, 645.0], [82.3, 645.0], [82.4, 646.0], [82.5, 646.0], [82.6, 646.0], [82.7, 647.0], [82.8, 648.0], [82.9, 648.0], [83.0, 648.0], [83.1, 649.0], [83.2, 650.0], [83.3, 651.0], [83.4, 651.0], [83.5, 651.0], [83.6, 652.0], [83.7, 653.0], [83.8, 653.0], [83.9, 653.0], [84.0, 654.0], [84.1, 654.0], [84.2, 656.0], [84.3, 657.0], [84.4, 657.0], [84.5, 657.0], [84.6, 657.0], [84.7, 658.0], [84.8, 658.0], [84.9, 659.0], [85.0, 659.0], [85.1, 660.0], [85.2, 660.0], [85.3, 660.0], [85.4, 661.0], [85.5, 663.0], [85.6, 663.0], [85.7, 663.0], [85.8, 663.0], [85.9, 664.0], [86.0, 665.0], [86.1, 666.0], [86.2, 666.0], [86.3, 667.0], [86.4, 668.0], [86.5, 668.0], [86.6, 668.0], [86.7, 669.0], [86.8, 669.0], [86.9, 670.0], [87.0, 670.0], [87.1, 670.0], [87.2, 670.0], [87.3, 671.0], [87.4, 673.0], [87.5, 673.0], [87.6, 673.0], [87.7, 674.0], [87.8, 675.0], [87.9, 676.0], [88.0, 677.0], [88.1, 677.0], [88.2, 677.0], [88.3, 678.0], [88.4, 680.0], [88.5, 680.0], [88.6, 681.0], [88.7, 682.0], [88.8, 683.0], [88.9, 684.0], [89.0, 685.0], [89.1, 685.0], [89.2, 685.0], [89.3, 686.0], [89.4, 686.0], [89.5, 688.0], [89.6, 689.0], [89.7, 690.0], [89.8, 692.0], [89.9, 692.0], [90.0, 693.0], [90.1, 694.0], [90.2, 694.0], [90.3, 695.0], [90.4, 696.0], [90.5, 697.0], [90.6, 698.0], [90.7, 700.0], [90.8, 702.0], [90.9, 704.0], [91.0, 705.0], [91.1, 705.0], [91.2, 706.0], [91.3, 708.0], [91.4, 709.0], [91.5, 710.0], [91.6, 712.0], [91.7, 713.0], [91.8, 713.0], [91.9, 714.0], [92.0, 716.0], [92.1, 719.0], [92.2, 719.0], [92.3, 720.0], [92.4, 724.0], [92.5, 728.0], [92.6, 729.0], [92.7, 731.0], [92.8, 732.0], [92.9, 733.0], [93.0, 734.0], [93.1, 738.0], [93.2, 740.0], [93.3, 741.0], [93.4, 744.0], [93.5, 744.0], [93.6, 745.0], [93.7, 748.0], [93.8, 748.0], [93.9, 751.0], [94.0, 753.0], [94.1, 757.0], [94.2, 759.0], [94.3, 765.0], [94.4, 770.0], [94.5, 773.0], [94.6, 773.0], [94.7, 775.0], [94.8, 776.0], [94.9, 778.0], [95.0, 779.0], [95.1, 780.0], [95.2, 781.0], [95.3, 785.0], [95.4, 785.0], [95.5, 790.0], [95.6, 795.0], [95.7, 797.0], [95.8, 799.0], [95.9, 802.0], [96.0, 804.0], [96.1, 805.0], [96.2, 809.0], [96.3, 809.0], [96.4, 813.0], [96.5, 821.0], [96.6, 824.0], [96.7, 827.0], [96.8, 828.0], [96.9, 831.0], [97.0, 835.0], [97.1, 839.0], [97.2, 841.0], [97.3, 841.0], [97.4, 844.0], [97.5, 846.0], [97.6, 848.0], [97.7, 848.0], [97.8, 851.0], [97.9, 852.0], [98.0, 853.0], [98.1, 861.0], [98.2, 863.0], [98.3, 868.0], [98.4, 872.0], [98.5, 879.0], [98.6, 883.0], [98.7, 901.0], [98.8, 905.0], [98.9, 1198.0], [99.0, 1203.0], [99.1, 1220.0], [99.2, 1244.0], [99.3, 1246.0], [99.4, 1255.0], [99.5, 1259.0], [99.6, 1262.0], [99.7, 1277.0], [99.8, 1284.0], [99.9, 1293.0], [100.0, 1296.0]], "isOverall": false, "label": "01_普通用户登录", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 100.0, "maxY": 761.0, "series": [{"data": [[1100.0, 1.0], [300.0, 236.0], [600.0, 297.0], [1200.0, 20.0], [700.0, 98.0], [200.0, 761.0], [400.0, 183.0], [800.0, 52.0], [100.0, 9.0], [900.0, 4.0], [500.0, 211.0]], "isOverall": false, "label": "01_普通用户登录", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 1200.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 681.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 1191.0, "series": [{"data": [[0.0, 1191.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 681.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 1.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 9.0, "minX": 1.79381802E12, "maxY": 9.0, "series": [{"data": [[1.79381814E12, 9.0], [1.79381808E12, 9.0], [1.79381826E12, 9.0], [1.7938182E12, 9.0], [1.79381832E12, 9.0], [1.79381802E12, 9.0]], "isOverall": false, "label": "登录线程组", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79381832E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 435.345085470086, "minX": 9.0, "maxY": 435.345085470086, "series": [{"data": [[9.0, 435.345085470086]], "isOverall": false, "label": "01_普通用户登录", "isController": false}, {"data": [[9.0, 435.345085470086]], "isOverall": false, "label": "01_普通用户登录-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 9.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 1861.0, "minX": 1.79381802E12, "maxY": 8158.666666666667, "series": [{"data": [[1.79381814E12, 6358.416666666667], [1.79381808E12, 6358.416666666667], [1.79381826E12, 6513.5], [1.7938182E12, 6513.5], [1.79381832E12, 1861.0], [1.79381802E12, 4652.5]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.79381814E12, 7963.166666666667], [1.79381808E12, 7956.5], [1.79381826E12, 8158.666666666667], [1.7938182E12, 8154.4], [1.79381832E12, 2328.3333333333335], [1.79381802E12, 5826.733333333334]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79381832E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 411.99999999999994, "minX": 1.79381802E12, "maxY": 456.53703703703684, "series": [{"data": [[1.79381814E12, 437.78048780487796], [1.79381808E12, 452.89701897018966], [1.79381826E12, 411.99999999999994], [1.7938182E12, 435.55026455026444], [1.79381832E12, 456.53703703703684], [1.79381802E12, 431.94814814814816]], "isOverall": false, "label": "01_普通用户登录", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79381832E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 411.64021164021125, "minX": 1.79381802E12, "maxY": 456.19444444444457, "series": [{"data": [[1.79381814E12, 437.4037940379405], [1.79381808E12, 452.52303523035255], [1.79381826E12, 411.64021164021125], [1.7938182E12, 435.18783068783074], [1.79381832E12, 456.19444444444457], [1.79381802E12, 431.5]], "isOverall": false, "label": "01_普通用户登录", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79381832E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 5.346883468834688, "minX": 1.79381802E12, "maxY": 5.988888888888886, "series": [{"data": [[1.79381814E12, 5.346883468834688], [1.79381808E12, 5.745257452574529], [1.79381826E12, 5.354497354497358], [1.7938182E12, 5.539682539682537], [1.79381832E12, 5.388888888888888], [1.79381802E12, 5.988888888888886]], "isOverall": false, "label": "01_普通用户登录", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79381832E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 188.0, "minX": 1.79381802E12, "maxY": 1296.0, "series": [{"data": [[1.79381814E12, 863.0], [1.79381808E12, 1296.0], [1.79381826E12, 861.0], [1.7938182E12, 1268.0], [1.79381832E12, 868.0], [1.79381802E12, 809.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.79381814E12, 188.0], [1.79381808E12, 217.0], [1.79381826E12, 205.0], [1.7938182E12, 192.0], [1.79381832E12, 214.0], [1.79381802E12, 216.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.79381814E12, 698.0], [1.79381808E12, 773.0], [1.79381826E12, 680.1], [1.7938182E12, 708.3000000000001], [1.79381832E12, 660.1000000000001], [1.79381802E12, 670.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.79381814E12, 851.6], [1.79381808E12, 1285.5], [1.79381826E12, 848.21], [1.7938182E12, 1250.2599999999998], [1.79381832E12, 868.0], [1.79381802E12, 776.1600000000001]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.79381814E12, 428.0], [1.79381808E12, 368.0], [1.79381826E12, 315.5], [1.7938182E12, 309.0], [1.79381832E12, 438.0], [1.79381802E12, 349.5]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.79381814E12, 783.0], [1.79381808E12, 862.5], [1.79381826E12, 729.05], [1.7938182E12, 804.05], [1.79381832E12, 841.0], [1.79381802E12, 732.9]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79381832E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 230.5, "minX": 1.0, "maxY": 430.0, "series": [{"data": [[1.0, 401.5], [8.0, 405.0], [4.0, 230.5], [2.0, 396.0], [9.0, 358.0], [5.0, 294.5], [3.0, 320.0], [6.0, 430.0], [7.0, 408.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 9.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 229.5, "minX": 1.0, "maxY": 429.0, "series": [{"data": [[1.0, 401.5], [8.0, 405.0], [4.0, 229.5], [2.0, 395.5], [9.0, 357.0], [5.0, 294.0], [3.0, 319.0], [6.0, 429.0], [7.0, 408.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 9.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 1.8, "minX": 1.79381802E12, "maxY": 6.3, "series": [{"data": [[1.79381814E12, 6.15], [1.79381808E12, 6.15], [1.79381826E12, 6.3], [1.7938182E12, 6.3], [1.79381832E12, 1.8], [1.79381802E12, 4.5]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79381832E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 1.8, "minX": 1.79381802E12, "maxY": 6.3, "series": [{"data": [[1.79381814E12, 6.15], [1.79381808E12, 6.15], [1.79381826E12, 6.3], [1.7938182E12, 6.3], [1.79381832E12, 1.8], [1.79381802E12, 4.5]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79381832E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 1.8, "minX": 1.79381802E12, "maxY": 6.3, "series": [{"data": [[1.79381814E12, 6.15], [1.79381808E12, 6.15], [1.79381826E12, 6.3], [1.7938182E12, 6.3], [1.79381832E12, 1.8], [1.79381802E12, 4.5]], "isOverall": false, "label": "01_普通用户登录-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79381832E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 1.8, "minX": 1.79381802E12, "maxY": 6.3, "series": [{"data": [[1.79381814E12, 6.15], [1.79381808E12, 6.15], [1.79381826E12, 6.3], [1.7938182E12, 6.3], [1.79381832E12, 1.8], [1.79381802E12, 4.5]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79381832E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

